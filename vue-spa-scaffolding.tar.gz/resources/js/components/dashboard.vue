<template>
</template>

<script>
	export default {
		name: "dashboard",
		data: () => {
			return {};
		},
		methods: {},
		mounted() {
		},
	};
</script>

<style scoped lang="scss">
</style>