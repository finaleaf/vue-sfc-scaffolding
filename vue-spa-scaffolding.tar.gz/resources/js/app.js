window.$ = window.jQuery = require("jquery");

import '@babel/polyfill';
import Vue from "vue";
import VueRouter from "vue-router";
import axios from "axios";
import VueAxios from "vue-axios";
import App from "./layout";
import "bootstrap/dist/css/bootstrap.css";
import "popper.js";
import "bootstrap";
import routes from "./routes";
import "./filters";
import VueToast from "vue-toast-notification";
import "vue-toast-notification/dist/theme-sugar.css";


Vue.use(VueAxios, axios);
Vue.use(VueRouter);
Vue.use(VueToast, {
	position: "bottom",
});
const router = new VueRouter({routes, mode: "history"});
const app = new Vue({
	el: '#app',
	data: {
		config: {
			
		}
	},
	methods: {
		clone(obj) {
			return JSON.parse(JSON.stringify(obj));
		},
		generateFormData(obj, method) {
			let formData = new FormData();
			for (let key in obj) {
				formData.append(key, typeof obj[key] === "object" ? JSON.stringify(obj[key]) : obj[key]);
			}
			if (method !== undefined) {
				formData.append("_method", method);
			}
			return formData;
		}
	},

	render: h => h(App),
	router: router,
});

