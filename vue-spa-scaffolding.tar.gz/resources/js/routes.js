import dashboard from "./components/dashboard";

const routes = [
	{path: "/", dashboard: dashboard},	
];
export default routes;
