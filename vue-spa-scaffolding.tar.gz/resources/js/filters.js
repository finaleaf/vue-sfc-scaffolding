import Vue from "vue";

Vue.filter("currency", value => {
	value = parseInt(value);
	if (!value) return '0';
	return value.toFixed(0).replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,")
});
