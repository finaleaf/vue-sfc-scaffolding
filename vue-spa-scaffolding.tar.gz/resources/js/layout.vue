<template>
	<div class="container-fluid stage">
		
	</div>
</template>
<script>

	export default {
		data: () => {
			return {				
			};
		},
		methods: {			
		},		
		mounted() {		
		},		
	} </script>
<style scoped lang="scss">	
</style>

